export const INSTRUMENT_PROFILES = Object.freeze([
  {key:'violin',label:'Violon',answer:'violon',timbreId:'sampled-violin',sourceFolder:'violin',familyId:'bowedStrings',familyLabel:'cordes frottées',anchors:[['A3',57],['A4',69],['A5',81],['A6',93]],identityMidi:[57,69,81],cue:'attaque souple et son entretenu des cordes frottées'},
  {key:'cello',label:'Violoncelle',answer:'violoncelle',timbreId:'sampled-cello',sourceFolder:'cello',familyId:'bowedStrings',familyLabel:'cordes frottées',anchors:[['A2',45],['A3',57],['A4',69]],identityMidi:[45,57,69],cue:'registre plus grave, attaque d’archet et résonance ample des cordes frottées'},
  {key:'flute',label:'Flûte',answer:'flûte',timbreId:'sampled-flute',sourceFolder:'flute',familyId:'woodwinds',familyLabel:'bois',anchors:[['C4',60],['C5',72],['C6',84],['C7',96]],identityMidi:[60,72,84],cue:'souffle clair et son lisse du bois'},
  {key:'clarinet',label:'Clarinette',answer:'clarinette',timbreId:'sampled-clarinet',sourceFolder:'clarinet',familyId:'woodwinds',familyLabel:'bois',anchors:[['D3',50],['D4',62],['As4',70]],identityMidi:[50,62,70],cue:'son boisé, sombre dans le grave puis plus clair en montant'},
  {key:'guitar',label:'Guitare acoustique',answer:'guitare acoustique',timbreId:'sampled-guitar',sourceFolder:'guitar-acoustic',familyId:'pluckedStrings',familyLabel:'cordes pincées',anchors:[['C3',48],['C4',60],['C5',72]],identityMidi:[48,60,72],cue:'attaque pincée puis décroissance rapide'},
  {key:'trumpet',label:'Trompette',answer:'trompette',timbreId:'sampled-trumpet',sourceFolder:'trumpet',familyId:'brass',familyLabel:'cuivres',anchors:[['F3',53],['F4',65],['D5',74],['C6',84]],identityMidi:[53,65,74],cue:'attaque franche et éclat du cuivre'},
  {key:'frenchHorn',label:'Cor',answer:'cor',timbreId:'sampled-french-horn',sourceFolder:'french-horn',familyId:'brass',familyLabel:'cuivres',anchors:[['D3',50],['A3',57],['C4',60]],identityMidi:[50,57,60],cue:'cuivre rond, moins éclatant que la trompette, avec une attaque plus douce'},
  {key:'xylophone',label:'Xylophone',answer:'xylophone',timbreId:'sampled-xylophone',sourceFolder:'xylophone',familyId:'malletPercussion',familyLabel:'percussions à lames',anchors:[['G4',67],['G5',79],['G6',91],['G7',103]],identityMidi:[67,79,91],cue:'attaque très nette et résonance courte des lames'}
]);

export const INSTRUMENT_BY_KEY = Object.freeze(Object.fromEntries(INSTRUMENT_PROFILES.map(x=>[x.key,x])));
export const INSTRUMENT_BY_TIMBRE = Object.freeze(Object.fromEntries(INSTRUMENT_PROFILES.map(x=>[x.timbreId,x])));
export const REAL_INSTRUMENT_TIMBRE_IDS = Object.freeze(INSTRUMENT_PROFILES.map(x=>x.timbreId));
export const TIMBRE_FAMILIES = Object.freeze([
  {id:'bowedStrings',label:'cordes frottées',instrumentKeys:['violin','cello']},
  {id:'woodwinds',label:'bois',instrumentKeys:['flute','clarinet']},
  {id:'brass',label:'cuivres',instrumentKeys:['trumpet','frenchHorn']}
]);
export const TIMBRE_FAMILY_BY_ID = Object.freeze(Object.fromEntries(TIMBRE_FAMILIES.map(x=>[x.id,x])));
