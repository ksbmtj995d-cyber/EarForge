import { CURRICULUM, adaptiveChapterIndex } from './curriculum.js';
import { familyMastery, mastery, productionMastery, transferMastery } from './scheduler.js';
import { forgettingProbeNeed, forgettingSummary } from './forgetting.js';
import { transferProbeNeed } from './transfer.js';
import { latestPitchJndMeasurement, pitchJndMeasurementDue } from './psychophysics.js';

function dayKey(ts){const d=new Date(ts);return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`;}
export function sessionsToday(progress,now=Date.now()){const key=dayKey(now);return (progress.history||[]).filter(x=>x?.endedAt&&dayKey(x.endedAt)===key);}
export function activeDaysLast7(progress,now=Date.now()){const floor=now-6*86400000;return new Set((progress.history||[]).filter(x=>x?.endedAt>=floor&&x.endedAt<=now).map(x=>dayKey(x.endedAt))).size;}
export function dueSkills(progress,now=Date.now()){return Object.entries(progress.skills||{}).filter(([,s])=>(s.attempts||0)>0&&s.nextDueAt>0&&s.nextDueAt<=now).sort((a,b)=>(a[1].nextDueAt||0)-(b[1].nextDueAt||0));}
export function weakestSkills(progress,limit=5){return Object.entries(progress.skills||{}).filter(([,s])=>(s.attempts||0)>0).sort((a,b)=>mastery(a[1])-mastery(b[1])).slice(0,limit);}
export function retentionDueSkills(progress,now=Date.now(),threshold=.55){return Object.entries(progress.skills||{}).filter(([,s])=>(s.attempts||0)>0&&forgettingProbeNeed(s,now)>=threshold).sort((a,b)=>forgettingProbeNeed(b[1],now)-forgettingProbeNeed(a[1],now));}
export function productionGapSkills(progress,limit=5){return Object.entries(progress.skills||{}).map(([key,s])=>({key,s,recognition:mastery(s),production:productionMastery(s),productionAttempts:s.evidence?.production?.attempts||0})).filter(x=>x.key.startsWith('interval:')&&x.recognition>=.62).map(x=>({...x,gap:x.recognition-x.production})).sort((a,b)=>b.gap-a.gap||a.productionAttempts-b.productionAttempts).slice(0,limit);}


export function transferGapSkills(progress,limit=5){return Object.entries(progress.skills||{}).map(([key,s])=>({key,s,recognition:mastery(s),transfer:transferMastery(s),transferAttempts:s.evidence?.transfer?.attempts||0,need:transferProbeNeed(s)})).filter(x=>x.recognition>=.62&&x.need>0).map(x=>({...x,gap:x.recognition-x.transfer})).sort((a,b)=>b.need-a.need||b.gap-a.gap).slice(0,limit);}
export function memoryCalibration(progress,now=Date.now()){const rows=Object.values(progress.skills||{}).filter(s=>(s.evidence?.forgetting?.observations?.length||0)>0).map(s=>forgettingSummary(s,now));const stabilities=rows.map(x=>x.stabilityDays).sort((a,b)=>a-b);return{skills:rows.length,medianStabilityDays:stabilities.length?stabilities[Math.floor((stabilities.length-1)/2)]:null,meanPredictedRecall:rows.length?rows.reduce((sum,x)=>sum+(x.predictedRecall??0),0)/rows.length:null};}

export function buildDailyPlan(progress,settings={},now=Date.now()){
  const due=dueSkills(progress,now), retentionDue=retentionDueSkills(progress,now), productionGaps=productionGapSkills(progress,3), transferGaps=transferGapSkills(progress,3), memory=memoryCalibration(progress,now), weak=weakestSkills(progress,3), chapterIndex=adaptiveChapterIndex(progress,familyMastery), chapter=CURRICULUM[chapterIndex], pitchJnd=latestPitchJndMeasurement(progress), pitchJndDue=pitchJndMeasurementDue(progress,now);
  const today=sessionsToday(progress,now), base=Math.min(30,Math.max(5,Number(settings.dailyTargetMinutes)||10));
  const recommendedMinutes=base;
  const lastBackup=Date.parse(settings.lastBackupAt||'')||0;
  const backupDue=(progress.sessionsCompleted||0)>=2&&(!lastBackup||now-lastBackup>14*86400000);
  let guidance;
  if(backupDue)guidance={kind:'backup',text:'Une sauvegarde de la progression est recommandée.',action:'Sauvegarder'};
  else if(retentionDue.length)guidance={kind:'review',text:`${retentionDue.length} exercice${retentionDue.length>1?'s':''} mérite${retentionDue.length>1?'nt':''} d’être revu${retentionDue.length>1?'s':''} aujourd’hui pour consolider les acquis.`,action:'Réviser'};
  else if(due.length)guidance={kind:'review',text:`${due.length} exercice${due.length>1?'s':''} est${due.length>1?'sont':''} prêt${due.length>1?'s':''} à être revu${due.length>1?'s':''}.`,action:'Réviser'};
  else if((progress.totalAttempts||0)>=40&&transferGaps.length&&(progress.totalTransferAttempts||0)<Math.max(5,(progress.totalAttempts||0)*.09))guidance={kind:'variety',text:'La séance peut maintenant varier davantage les instruments pour consolider les repères.',action:'Commencer'};
  else if((progress.totalAttempts||0)>=30&&productionGaps.length&&(progress.totalProductionAttempts||0)<Math.max(4,(progress.totalAttempts||0)*.08))guidance={kind:'singing',text:'Un court exercice chanté peut compléter le travail d’écoute aujourd’hui.',action:'Chanter'};
  else if(pitchJndDue)guidance={kind:'precision',text:'Un exercice de précision est disponible pour comparer des notes très proches.',action:'Comparer'};
  else if(!today.length)guidance=(progress.totalAttempts||0)===0?{kind:'practice',text:`Commence par une séance d’environ ${recommendedMinutes} minutes pour découvrir les premiers exercices.`,action:'Commencer'}:{kind:'practice',text:`Environ ${recommendedMinutes} minutes suffisent aujourd’hui pour poursuivre la progression.`,action:'Commencer'};
  else guidance={kind:'done',text:'La séance prévue aujourd’hui est terminée. Il reste possible de choisir un exercice libre.',action:null};
  return {date:dayKey(now),targetMinutes:base,recommendedMinutes,dueCount:due.length,retentionDueCount:retentionDue.length,productionGap:productionGaps[0]||null,transferGap:transferGaps[0]||null,memory,weakSkills:weak.map(([key,s])=>({key,mastery:mastery(s)})),chapterIndex,chapterTitle:chapter?.title||'',sessionsToday:today.length,minutesToday:today.reduce((sum,x)=>sum+(Number(x.elapsedMinutes)||Number(x.durationMinutes)||0),0),activeDays7:activeDaysLast7(progress,now),backupDue,pitchJnd,pitchJndDue,guidance};
}

export function buildWeeklyPlan(progress,settings={},now=Date.now()){
  const buckets=Array.from({length:7},(_,i)=>({offset:i,date:dayKey(now+i*86400000),due:0,retention:0,recommendedMinutes:Math.min(30,Math.max(5,Number(settings.dailyTargetMinutes)||10))}));
  for(const s of Object.values(progress.skills||{})){
    if(!(s.attempts||0)||!s.nextDueAt)continue;
    const diff=Math.floor((new Date(s.nextDueAt).setHours(0,0,0,0)-new Date(now).setHours(0,0,0,0))/86400000);
    if(diff>=0&&diff<7)buckets[diff].due+=1;
  }
  for(const [key,s] of Object.entries(progress.skills||{})){if(!(s.attempts||0))continue;for(let i=0;i<7;i+=1){const t=now+i*86400000;if(forgettingProbeNeed(s,t)>=.55){buckets[i].retention+=1;break;}}}
  return buckets;
}
