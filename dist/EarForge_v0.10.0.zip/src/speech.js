function utteranceCtor(){return globalThis.SpeechSynthesisUtterance;}
export function speechSupported(synth=globalThis.speechSynthesis){return Boolean(synth&&utteranceCtor());}
export function frenchVoices(synth=globalThis.speechSynthesis){if(!synth?.getVoices)return[];return synth.getVoices().filter(v=>String(v.lang||'').toLowerCase().startsWith('fr')).sort((a,b)=>Number(Boolean(b.default))-Number(Boolean(a.default))||a.name.localeCompare(b.name));}
export function speak(text,{voiceURI=null,rate=1,synth=globalThis.speechSynthesis,timeoutMs=null}={}){
  return new Promise((resolve,reject)=>{
    if(!speechSupported(synth)){reject(new Error('Synthèse vocale indisponible.'));return;}
    const Utterance=utteranceCtor(),u=new Utterance(String(text));
    const voice=frenchVoices(synth).find(v=>v.voiceURI===voiceURI)||frenchVoices(synth)[0];if(voice)u.voice=voice;u.lang=voice?.lang||'fr-FR';u.rate=Math.max(.7,Math.min(1.3,Number(rate)||1));
    let settled=false,timer=null;const finish=(ok,error)=>{if(settled)return;settled=true;if(timer)clearTimeout(timer);u.onend=null;u.onerror=null;ok?resolve():reject(error||new Error('Synthèse vocale interrompue.'));};
    u.onend=()=>finish(true);u.onerror=e=>finish(false,new Error(e?.error||'Synthèse vocale interrompue.'));
    const boundedTimeout=Number(timeoutMs)||Math.min(15000,Math.max(3500,1600+String(text).length*85));
    timer=setTimeout(()=>{try{synth.cancel();}catch{}finish(false,new Error('La voix de l’appareil n’a pas répondu à temps.'));},boundedTimeout);
    try{try{synth.cancel();}catch{}try{synth.resume?.();}catch{}synth.speak(u);}catch(error){finish(false,error);}
  });
}
export function cancelSpeech(synth=globalThis.speechSynthesis){try{synth?.cancel?.();}catch{}}
