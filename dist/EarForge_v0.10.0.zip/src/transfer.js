import { ensureEvidenceState, posteriorMastery, posteriorUncertainty } from './evidence.js';
import { REAL_INSTRUMENT_TIMBRE_IDS } from './timbres.js';

const ELIGIBLE = new Set(['pitchDirection','intervalSameDifferent','interval','intervalCompare','scale','chord','chordInversion','scaleDegree','pitchClass','cadence','progression','melodyContour','melodyMemory','errorDetection','tuning']);
export const SYNTH_TRANSFER_TIMBRES = Object.freeze(['sine','bright-synth']);
export const TRANSFER_TIMBRES = Object.freeze([...REAL_INSTRUMENT_TIMBRE_IDS,...SYNTH_TRANSFER_TIMBRES]);

export function transferProbeNeed(skill){
  const recognitionAttempts=Number(skill?.attempts)||0;
  const recognition=recognitionAttempts?skill.alpha/(skill.alpha+skill.beta):.5;
  if(recognitionAttempts<3||recognition<.62)return 0;
  const p=ensureEvidenceState(skill?.evidence).transfer;
  const coverage=Math.max(0,1-Math.min(1,p.attempts/5));
  const uncertainty=Math.min(1,posteriorUncertainty(p)*4.5);
  const weakness=1-posteriorMastery(p);
  return Math.min(1,.4*coverage+.32*uncertainty+.28*weakness);
}

export function itemTransferNeed(progress,item){
  if(!item||item.learningAxis&&item.learningAxis!=='recognition'||!ELIGIBLE.has(item.family))return 0;
  const keys=item.skillKeys||[];
  if(!keys.length)return 0;
  return Math.max(0,...keys.map(k=>transferProbeNeed(progress.skills?.[k])));
}

export function shouldProbeTransfer(progress,item,prng,options={}){
  const need=itemTransferNeed(progress,item);
  if(need<=0)return false;
  const base=Number(options.baseRate??.04),max=Number(options.maxRate??.18);
  const probability=Math.min(max,base+(max-base)*need);
  return prng.next()<probability;
}

export function makeTransferProbe(item,prng,options={}){
  const pool=Array.isArray(options.timbres)&&options.timbres.length?options.timbres:TRANSFER_TIMBRES;
  const timbre=prng.pick(pool);
  return {...item,id:`${item.id}:transfer:${timbre}`,learningAxis:'transfer',timbreOverride:timbre,transferSourceFamily:item.family,contextTags:[...(item.contextTags||[]),`transfer:timbre:${timbre}`],label:`${item.label} · autre instrument`};
}
