import { generateItem } from './registry.js';
import { globalLevel, makeScheduler, sessionSeed, uncertainty } from './scheduler.js';
import { makeTransferProbe, shouldProbeTransfer } from './transfer.js';

export const DEFAULT_SECONDS_PER_ITEM=25;
export function targetItemCount(minutes,seconds=DEFAULT_SECONDS_PER_ITEM){return Math.max(6,Math.round(((Number(minutes)||10)*60)/seconds));}
function clampMinutes(value){const n=Number(value)||10;return Math.min(30,Math.max(5,n));}

export function createAdaptiveSession(progress,options={}){
  const durationMinutes=clampMinutes(options.durationMinutes);
  const startAt=options.startAt||Date.now();
  const nominalItems=targetItemCount(durationMinutes,options.secondsPerItem);
  const fixedTarget=Number.isFinite(Number(options.itemCount))&&Number(options.itemCount)>0;
  const targetItems=fixedTarget?Math.max(1,Math.round(Number(options.itemCount))):null;
  const minItems=fixedTarget?targetItems:Math.max(6,Math.round(nominalItems*.55));
  const maxItems=fixedTarget?targetItems:Math.max(minItems+2,Math.round(nominalItems*1.35));
  const seed=options.seed??sessionSeed(progress,startAt,options.salt||'earforge-v09');
  const excludedFamilies=Array.isArray(options.excludedFamilies)?[...options.excludedFamilies]:[];
  const sampleDependentAllowed=options.sampleDependentAllowed!==false;
  return {schemaVersion:3,id:`session-${startAt}-${seed.toString(16)}`,seed,createdAt:startAt,durationMinutes,nominalItems,targetItems,minItems,maxItems,fixedTarget,mode:options.mode||'multipleChoice',allowedFamilies:options.allowedFamilies||null,excludedFamilies,sampleDependentAllowed,itemIndex:0,results:[],exposures:0,scheduler:makeScheduler(progress,seed,startAt,{allowedFamilies:options.allowedFamilies||null,excludedFamilies})};
}

export function adaptiveStopDecision(session,progress,now=Date.now()){
  if(!session)return{stop:true,reason:'no_session'};
  const completed=(session.results||[]).length;
  if(session.fixedTarget)return{stop:completed>=session.targetItems,reason:completed>=session.targetItems?'fixed_complete':'fixed_continue'};
  if(session.mode==='handsFree')return{stop:session.itemIndex>=session.maxItems,reason:session.itemIndex>=session.maxItems?'exposure_ceiling':'exposure_continue'};
  const targetMs=session.durationMinutes*60000;
  const elapsed=Math.max(0,now-session.createdAt);
  if(completed>=session.maxItems||elapsed>=targetMs*1.3)return{stop:true,reason:'ceiling'};
  if(completed<session.minItems&&elapsed<targetMs*.8)return{stop:false,reason:'minimum_not_reached'};
  const recent=(session.results||[]).slice(-8);
  if(!recent.length)return{stop:false,reason:'no_evidence'};
  const strict=recent.filter(r=>r.correct===true||r.grade==='known').length/recent.length;
  const keys=[...new Set(recent.flatMap(r=>r.skillKeys||[]))];
  const meanUncertainty=keys.length?keys.reduce((sum,k)=>sum+uncertainty(progress.skills?.[k]),0)/keys.length:.25;
  const dueCount=Object.values(progress.skills||{}).filter(s=>(s.attempts||0)>0&&s.nextDueAt>0&&s.nextDueAt<=now).length;
  const struggling=strict<.58||meanUncertainty>.19;
  const stable=strict>=.85&&meanUncertainty<=.17&&dueCount<=2;
  if(elapsed>=targetMs*.8&&completed>=session.minItems&&stable)return{stop:true,reason:'stable_early',strict,meanUncertainty,dueCount};
  if(elapsed>=targetMs){
    if(struggling&&completed<session.maxItems&&elapsed<targetMs*1.25)return{stop:false,reason:'repair_extension',strict,meanUncertainty,dueCount};
    return{stop:true,reason:'target_reached',strict,meanUncertainty,dueCount};
  }
  return{stop:false,reason:'continue',strict,meanUncertainty,dueCount};
}

export function nextAdaptiveItem(session,progress){
  if(session.fixedTarget&&session.itemIndex>=session.targetItems)return null;
  if(!session.fixedTarget&&session.itemIndex>=session.maxItems)return null;
  session.scheduler.setProgress(progress);
  const {familyId,targetSkillKey,contextHint}=session.scheduler.nextTarget();
  if(!familyId)return null;
  let item=generateItem(familyId,{prng:session.scheduler.prng,level:globalLevel(progress),itemIndex:session.itemIndex,targetSkillKey,contextHint});
  if(!session.fixedTarget&&session.mode!=='handsFree'&&shouldProbeTransfer(progress,item,session.scheduler.prng))item=makeTransferProbe(item,session.scheduler.prng,{timbres:session.sampleDependentAllowed?undefined:['sine','bright-synth']});
  session.itemIndex+=1;
  return item;
}

export function buildSession(progress,options={}){const s=createAdaptiveSession(progress,options),items=[];const limit=s.fixedTarget?s.targetItems:s.nominalItems;while(items.length<limit){const x=nextAdaptiveItem(s,progress);if(!x)break;items.push(x);}return {...s,items,scheduler:undefined};}
export function sessionSummary(session,results=session.results||[],endedAt=Date.now()){
  const graded=results.filter(Boolean),strict=graded.filter(r=>r.correct===true||r.grade==='known').length,positive=graded.filter(r=>r.correct===true||['known','almost'].includes(r.grade)).length;
  return {sessionId:session.id,mode:session.mode,durationMinutes:session.durationMinutes,elapsedMinutes:Math.max(0,(endedAt-session.createdAt)/60000),fixedTarget:Boolean(session.fixedTarget),plannedItems:session.targetItems??session.nominalItems,completedItems:graded.length,strictCorrect:strict,positive,accuracy:graded.length?strict/graded.length:0,exposures:session.exposures||0,endedAt};
}
