import { createProgress, ensureProgressShape } from './scheduler.js';
import { APP_VERSION, STATE_SCHEMA_VERSION } from './version.js';
import { REAL_INSTRUMENT_TIMBRE_IDS } from './timbres.js';

const KEY='earforge.progress.v7',BACKUPS=['earforge.progress.v7.backup1','earforge.progress.v7.backup2','earforge.progress.v7.backup3'];
const LEGACY_KEYS=['earforge.progress.v6','earforge.progress.v6.backup1','earforge.progress.v6.backup2','earforge.progress.v6.backup3','earforge.progress.v5','earforge.progress.v5.backup1','earforge.progress.v5.backup2','earforge.progress.v5.backup3','earforge.progress.v4','earforge.progress.v4.backup1','earforge.progress.v4.backup2','earforge.progress.v4.backup3','earforge.progress.v3','earforge.progress.v3.backup','earforge.progress.v2','earforge.progress.v1'];
const SETTINGS_KEY='earforge.settings.v7',LEGACY_SETTINGS=['earforge.settings.v6','earforge.settings.v5','earforge.settings.v4','earforge.settings.v3','earforge.settings.v2'];
const MAX_IMPORT_BYTES=5*1024*1024;
export const DEFAULT_SETTINGS={dailyTargetMinutes:10,manualQuestionCount:10,mode:'multipleChoice',timbre:'sampled-piano',masterVolume:.58,confirmationDelayMs:1800,chainPlayback:true,handsFreeThinkMs:3500,speechRate:1,speechVoiceURI:null,voiceCenterMidi:60,voiceCalibrated:false,lastBackupAt:null};
const ALLOWED_SETTINGS=new Set(Object.keys(DEFAULT_SETTINGS));
const ALLOWED_TIMBRES=new Set(['sampled-piano',...REAL_INSTRUMENT_TIMBRE_IDS,'ear-piano','sine']);

function safeProgress(raw){return ensureProgressShape(JSON.parse(raw));}
function boundedNumber(v,min,max,fallback){const n=Number(v);return Number.isFinite(n)?Math.min(max,Math.max(min,n)):fallback;}
export function sanitizeSettings(input={}){
  const out={...DEFAULT_SETTINGS};
  for(const [k,v] of Object.entries(input||{}))if(ALLOWED_SETTINGS.has(k))out[k]=v;
  out.dailyTargetMinutes=[5,10,15,20,30].includes(Number(out.dailyTargetMinutes))?Number(out.dailyTargetMinutes):10;
  out.manualQuestionCount=[6,10,15,20,30].includes(Number(out.manualQuestionCount))?Number(out.manualQuestionCount):10;
  out.mode=['multipleChoice','selfGrade'].includes(out.mode)?out.mode:'multipleChoice';
  out.timbre=ALLOWED_TIMBRES.has(out.timbre)?out.timbre:'sampled-piano';
  out.masterVolume=boundedNumber(out.masterVolume,.05,.9,.58);
  out.confirmationDelayMs=[900,1800,2800,4000].includes(Number(out.confirmationDelayMs))?Number(out.confirmationDelayMs):1800;
  out.handsFreeThinkMs=[2000,3500,5000,8000].includes(Number(out.handsFreeThinkMs))?Number(out.handsFreeThinkMs):3500;
  out.speechRate=boundedNumber(out.speechRate,.7,1.3,1);
  out.speechVoiceURI=typeof out.speechVoiceURI==='string'&&out.speechVoiceURI?out.speechVoiceURI:null;
  out.voiceCenterMidi=Math.round(boundedNumber(out.voiceCenterMidi,48,76,60));
  out.voiceCalibrated=Boolean(out.voiceCalibrated);
  out.chainPlayback=Boolean(out.chainPlayback);
  out.lastBackupAt=typeof out.lastBackupAt==='string'&&Number.isFinite(Date.parse(out.lastBackupAt))?out.lastBackupAt:null;
  return out;
}

export function loadProgressRecord(storage=globalThis.localStorage){
  if(!storage)return{progress:createProgress(),source:'memory',recovered:false,migrated:false,error:'storage_unavailable'};
  const candidates=[[KEY,'primary'],...BACKUPS.map((k,i)=>[k,`backup${i+1}`]),...LEGACY_KEYS.map((k,i)=>[k,`legacy${i+1}`])],errors=[];
  for(const [key,source] of candidates){let raw;try{raw=storage.getItem(key);}catch(e){errors.push(`${key}: ${e.message}`);continue;}if(!raw)continue;try{return{progress:safeProgress(raw),source,recovered:source.startsWith('backup'),migrated:source.startsWith('legacy'),error:errors.length?errors.join(' | '):null};}catch(e){errors.push(`${key}: ${e.message}`);}}
  return{progress:createProgress(),source:'new',recovered:false,migrated:false,error:errors.length?errors.join(' | '):null};
}
export const loadProgress=(storage=globalThis.localStorage)=>loadProgressRecord(storage).progress;
export function saveProgress(progress,storage=globalThis.localStorage){
  if(!storage)return{ok:false,error:'storage_unavailable'};
  const serialized=JSON.stringify(ensureProgressShape(progress));
  try{
    const previous=storage.getItem(KEY),b1=storage.getItem(BACKUPS[0]),b2=storage.getItem(BACKUPS[1]);
    if(b2)storage.setItem(BACKUPS[2],b2);if(b1)storage.setItem(BACKUPS[1],b1);if(previous)storage.setItem(BACKUPS[0],previous);
    storage.setItem(KEY,serialized);return{ok:true,bytes:serialized.length};
  }catch(e){return{ok:false,error:e?.message||String(e)};
  }
}
export function resetProgress(storage=globalThis.localStorage){if(storage)for(const k of [KEY,...BACKUPS,...LEGACY_KEYS])try{storage.removeItem(k);}catch{}return createProgress();}
export function loadSettings(storage=globalThis.localStorage){if(!storage)return{...DEFAULT_SETTINGS};for(const key of [SETTINGS_KEY,...LEGACY_SETTINGS])try{const raw=storage.getItem(key);if(raw)return sanitizeSettings(JSON.parse(raw));}catch{}return{...DEFAULT_SETTINGS};}
export function saveSettings(settings,storage=globalThis.localStorage){if(!storage)return{ok:false,error:'storage_unavailable'};try{storage.setItem(SETTINGS_KEY,JSON.stringify(sanitizeSettings(settings)));return{ok:true};}catch(e){return{ok:false,error:e?.message||String(e)};}}

function stable(value){if(Array.isArray(value))return value.map(stable);if(value&&typeof value==='object'){const o={};for(const k of Object.keys(value).sort())o[k]=stable(value[k]);return o;}return value;}
function canonical(value){return JSON.stringify(stable(value));}
async function sha256(text){if(!globalThis.crypto?.subtle)throw new Error('SHA-256 indisponible dans cet environnement.');const data=new TextEncoder().encode(text),hash=await crypto.subtle.digest('SHA-256',data);return [...new Uint8Array(hash)].map(x=>x.toString(16).padStart(2,'0')).join('');}
function exportSummary(progress){return{sessionsCompleted:progress.sessionsCompleted||0,totalAttempts:progress.totalAttempts||0,totalCorrect:progress.totalCorrect||0,totalProductionAttempts:progress.totalProductionAttempts||0,totalProductionCorrect:progress.totalProductionCorrect||0,totalTransferAttempts:progress.totalTransferAttempts||0,totalExposures:progress.totalExposures||0,updatedAt:progress.updatedAt||null};}
export async function exportState(progress,settings){
  const core={format:'EarForgeBackup',version:STATE_SCHEMA_VERSION,appVersion:APP_VERSION,exportedAt:new Date().toISOString(),payload:{progress:ensureProgressShape(progress),settings:sanitizeSettings(settings)},summary:exportSummary(progress)};
  const digest=await sha256(canonical(core));
  return JSON.stringify({...core,integrity:{algorithm:'SHA-256',digest}},null,2);
}
export async function importState(text){
  if(typeof text!=='string'||new TextEncoder().encode(text).length>MAX_IMPORT_BYTES)throw new Error('Fichier trop volumineux ou invalide.');
  const p=JSON.parse(text);
  if(p?.format==='EarForgeState'&&[1,2,3].includes(p.version))return{progress:ensureProgressShape(p.progress),settings:sanitizeSettings(p.settings||{}),migrated:true};
  if(p?.format!=='EarForgeBackup'||![4,5,6,STATE_SCHEMA_VERSION].includes(p.version))throw new Error('Format EarForge non reconnu.');
  if(p.integrity?.algorithm!=='SHA-256'||typeof p.integrity?.digest!=='string')throw new Error('Empreinte de sauvegarde absente.');
  const core={format:p.format,version:p.version,appVersion:p.appVersion,exportedAt:p.exportedAt,payload:p.payload,summary:p.summary};
  const digest=await sha256(canonical(core));
  if(digest!==p.integrity.digest)throw new Error('Sauvegarde altérée : empreinte SHA-256 incorrecte.');
  if(!p.payload?.progress||!p.payload?.settings)throw new Error('Sauvegarde incomplète.');
  return{progress:ensureProgressShape(p.payload.progress),settings:sanitizeSettings(p.payload.settings),migrated:p.version!==STATE_SCHEMA_VERSION};
}

export function isStandaloneWebApp(nav=globalThis.navigator,matchMediaFn=globalThis.matchMedia){if(nav?.standalone===true)return true;try{return Boolean(matchMediaFn?.('(display-mode: standalone)')?.matches);}catch{return false;}}
export async function requestPersistentStorage(nav=globalThis.navigator,request=true){const s=nav?.storage;if(!s?.persisted)return{supported:false,persistent:null,requested:false,error:null};try{let persistent=await s.persisted(),requested=false;if(request&&!persistent&&s.persist){requested=true;persistent=await s.persist();}return{supported:true,persistent:Boolean(persistent),requested,error:null};}catch(e){return{supported:true,persistent:false,requested:false,error:e?.message||String(e)};}}
export async function storageDiagnostics(nav=globalThis.navigator,requestPersistence=false){const status=await requestPersistentStorage(nav,requestPersistence);let usage=null,quota=null;try{if(nav?.storage?.estimate){const e=await nav.storage.estimate();usage=Number.isFinite(e?.usage)?e.usage:null;quota=Number.isFinite(e?.quota)?e.quota:null;}}catch{}return{...status,usage,quota};}
