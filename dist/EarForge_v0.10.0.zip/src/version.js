export const APP_VERSION = '0.10.0';
export const STATE_SCHEMA_VERSION = 7;
export const CACHE_VERSION = 'earforge-shell-v10';
