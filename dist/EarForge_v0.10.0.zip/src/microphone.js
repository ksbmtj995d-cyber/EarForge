import { estimatePitchYin, robustPitchEstimate } from './pitch.js';

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export function microphoneErrorCode(error) {
  const name = error?.name || '';
  if (name === 'NotAllowedError' || name === 'SecurityError') return 'permission_denied';
  if (name === 'NotFoundError' || name === 'DevicesNotFoundError') return 'no_microphone';
  if (name === 'NotReadableError' || name === 'AbortError') return error?.code === 'cancelled' ? 'cancelled' : 'device_unavailable';
  return error?.code || 'microphone_error';
}

function cancelledError() {
  const error = new Error('Microphone request cancelled.');
  error.name = 'AbortError';
  error.code = 'cancelled';
  return error;
}

export class MicrophonePitchInput {
  constructor({ mediaDevices = globalThis.navigator?.mediaDevices, contextProvider, onStateChange = null } = {}) {
    this.mediaDevices = mediaDevices;
    this.contextProvider = contextProvider;
    this.onStateChange = onStateChange;
    this.stream = null;
    this.source = null;
    this.analyser = null;
    this.buffer = null;
    this.health = 'idle';
    this.lastError = null;
    this.requestGeneration = 0;
    this.deviceChangeHandler = null;
    this.routeChanged = false;
  }

  _setState(state, detail = {}) {
    this.health = state;
    try { this.onStateChange?.({ state, ...detail, diagnostics: this.diagnostics() }); } catch {}
  }

  _tracks() { return this.stream?.getAudioTracks?.() || []; }

  _setTracksEnabled(enabled) {
    for (const track of this._tracks()) {
      try { track.enabled = Boolean(enabled); } catch {}
    }
  }

  _removeDeviceListener() {
    if (this.deviceChangeHandler) {
      try { this.mediaDevices?.removeEventListener?.('devicechange', this.deviceChangeHandler); } catch {}
      this.deviceChangeHandler = null;
    }
  }

  _releaseStream() {
    this._removeDeviceListener();
    try { this.source?.disconnect?.(); } catch {}
    for (const track of this.stream?.getTracks?.() || []) { try { track.stop(); } catch {} }
    this.stream = null;
    this.source = null;
    this.analyser = null;
    this.buffer = null;
    this.routeChanged = false;
  }

  _bindLifecycle(stream) {
    for (const track of stream.getAudioTracks?.() || []) {
      track.enabled = false;
      track.addEventListener?.('mute', () => {
        if (stream !== this.stream) return;
        this._setTracksEnabled(false);
        this._setState('interrupted', { reason: 'muted' });
      });
      track.addEventListener?.('unmute', () => {
        if (stream !== this.stream || track.readyState === 'ended') return;
        this._setTracksEnabled(false);
        this._setState('prepared', { reason: 'unmuted' });
      });
      track.addEventListener?.('ended', () => {
        if (stream !== this.stream) return;
        this._setTracksEnabled(false);
        this._setState('ended', { reason: 'ended' });
      }, { once: true });
    }
    if (this.mediaDevices?.addEventListener) {
      this.deviceChangeHandler = () => {
        if (stream !== this.stream) return;
        this.routeChanged = true;
        this._setTracksEnabled(false);
        this._setState('interrupted', { reason: 'devicechange' });
      };
      this.mediaDevices.addEventListener('devicechange', this.deviceChangeHandler);
    }
  }

  async prepare() {
    if (!this.mediaDevices?.getUserMedia) throw Object.assign(new Error('Microphone Web indisponible.'), { code: 'unsupported' });
    if (this.health === 'prepared' && this.stream?.active) return this;
    if (this.health === 'capturing' && this.stream?.active) { await this.endCapture(); return this; }

    const generation = ++this.requestGeneration;
    this._releaseStream();
    this.lastError = null;
    this._setState('requesting');

    let stream = null;
    try {
      const context = await this.contextProvider?.();
      if (generation !== this.requestGeneration) throw cancelledError();
      if (!context) throw new Error('Contexte audio indisponible.');
      stream = await this.mediaDevices.getUserMedia({
        audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false },
        video: false,
      });
      if (generation !== this.requestGeneration) {
        for (const track of stream.getTracks?.() || []) { try { track.stop(); } catch {} }
        throw cancelledError();
      }
      const source = context.createMediaStreamSource(stream);
      const analyser = context.createAnalyser();
      analyser.fftSize = 4096;
      analyser.smoothingTimeConstant = 0;
      source.connect(analyser);
      this.stream = stream;
      this.source = source;
      this.analyser = analyser;
      this.buffer = new Float32Array(analyser.fftSize);
      this._bindLifecycle(stream);
      this._setTracksEnabled(false);
      this._setState('prepared');
      return this;
    } catch (error) {
      if (stream && stream !== this.stream) {
        for (const track of stream.getTracks?.() || []) { try { track.stop(); } catch {} }
      }
      if (error?.code === 'cancelled' || generation !== this.requestGeneration) throw cancelledError();
      this.lastError = error;
      error.code ||= microphoneErrorCode(error);
      this._setState('error', { errorCode: error.code });
      throw error;
    }
  }

  async start() { return this.prepare(); }

  async beginCapture() {
    if (this.health !== 'prepared' || !this.stream?.active) {
      await this.prepare();
    }
    if (this.health !== 'prepared' || !this.stream?.active) throw Object.assign(new Error('Microphone indisponible.'), { code: 'device_unavailable' });
    const tracks = this._tracks();
    if (!tracks.length || tracks.some((t) => t.readyState === 'ended' || t.muted)) {
      this._setTracksEnabled(false);
      this._setState('interrupted', { reason: 'track_unavailable' });
      throw Object.assign(new Error('Microphone interrompu.'), { code: 'device_unavailable' });
    }
    this.routeChanged = false;
    this._setTracksEnabled(true);
    this._setState('capturing');
    return this;
  }

  async endCapture() {
    this._setTracksEnabled(false);
    if (this.stream?.active && !['error', 'ended', 'idle'].includes(this.health)) this._setState('prepared');
    return this;
  }

  sample() {
    if (this.health !== 'capturing' || !this.analyser || !this.buffer || this.stream?.active === false) return null;
    this.analyser.getFloatTimeDomainData(this.buffer);
    return estimatePitchYin(this.buffer, this.analyser.context?.sampleRate || 48000, { minFrequency: 80, maxFrequency: 1000 });
  }

  async captureStable({ timeoutMs = 4200, intervalMs = 85, minFrames = 5, signal } = {}) {
    if (this.health !== 'capturing') return { status: this.health === 'interrupted' || this.health === 'ended' ? 'interrupted' : 'not_listening' };
    const started = performance.now();
    const estimates = [];
    while (performance.now() - started < timeoutMs) {
      if (signal?.aborted) return { status: 'aborted' };
      if (this.health !== 'capturing' || this.stream?.active === false) return { status: 'interrupted' };
      const estimate = this.sample();
      if (estimate) estimates.push(estimate);
      const robust = robustPitchEstimate(estimates.slice(-10), { minFrames, minClarity: .72, maxSpreadCents: 48 });
      if (robust) return { status: 'ok', ...robust };
      await sleep(intervalMs);
    }
    return { status: 'timeout', frames: estimates.length };
  }

  diagnostics() {
    const track = this._tracks()[0] || null;
    let settings = {};
    try { settings = track?.getSettings?.() || {}; } catch {}
    return {
      state: this.health,
      active: Boolean(this.stream?.active),
      trackEnabled: Boolean(track?.enabled),
      trackMuted: Boolean(track?.muted),
      trackReadyState: track?.readyState || null,
      routeChanged: this.routeChanged,
      latency: Number.isFinite(Number(settings.latency)) ? Number(settings.latency) : null,
      deviceIdPresent: Boolean(settings.deviceId),
    };
  }

  async stop() {
    this.requestGeneration += 1;
    this._releaseStream();
    this.lastError = null;
    this._setState('idle');
  }

  async recover() { await this.stop(); return this.prepare(); }
}
