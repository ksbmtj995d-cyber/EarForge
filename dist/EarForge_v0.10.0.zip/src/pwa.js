let updateRequested=false;
export async function registerEarForgePWA({onStatus=()=>{},onUpdateReady=()=>{}}={}){
  if(!('serviceWorker' in navigator)){onStatus('Le mode hors connexion n’est pas disponible ici.');return null;}
  const registration=await navigator.serviceWorker.register('./sw.js');
  onStatus('Mode hors connexion prêt.');
  const signal=()=>{if(registration.waiting)onUpdateReady(registration);};
  signal();
  registration.addEventListener('updatefound',()=>{
    const worker=registration.installing;if(!worker)return;
    worker.addEventListener('statechange',()=>{if(worker.state==='installed'&&navigator.serviceWorker.controller)setTimeout(signal,0);});
  });
  setTimeout(()=>registration.update().catch(()=>{}),1500);
  return registration;
}
export function applyWaitingUpdate(registration){if(registration?.waiting){updateRequested=true;registration.waiting.postMessage({type:'SKIP_WAITING'});}}
export function reloadOnControllerChange(){let reloading=false;navigator.serviceWorker?.addEventListener('controllerchange',()=>{if(!updateRequested||reloading)return;reloading=true;location.reload();});}
