# Third-party notices

EarForge peut charger des échantillons audio tiers à la demande. Ces fichiers audio ne sont pas inclus dans la distribution EarForge.

## Salamander Grand Piano

- Instrument : Yamaha C5
- Échantillonnage : Alexander Holm
- Licence : Creative Commons Attribution 3.0 (CC BY 3.0)
- Source : Salamander Grand Piano / Tone.js audio samples

## tonejs-instruments

EarForge peut charger des échantillons de violon, flûte, guitare acoustique, trompette et xylophone depuis la collection `tonejs-instruments`.

- Collection : Nicholaus P. Brosowsky
- Licence des échantillons indiquée par le projet source : CC BY 3.0
- Sources indiquées par le projet source pour les instruments utilisés : Versilian Community Sample Library (violon, flûte, trompette, xylophone) et University of Iowa Electronic Music Studios (guitare acoustique)
- Source : https://github.com/nbrosowsky/tonejs-instruments

Les conditions des œuvres tierces restent applicables indépendamment de la licence d’EarForge.
