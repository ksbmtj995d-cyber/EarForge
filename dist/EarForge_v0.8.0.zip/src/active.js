import { INTERVALS, midiToFrequency } from './music.js';
import { productionMastery, mastery } from './scheduler.js';
import { ensureEvidenceState, posteriorUncertainty } from './evidence.js';

const TRAINABLE_INTERVALS = INTERVALS.filter((x) => x.semitones >= 1 && x.semitones <= 12);

export function chooseProductionInterval(progress, prng) {
  const scored = TRAINABLE_INTERVALS.map((interval) => {
    const key = `interval:${interval.semitones}`;
    const skill = progress.skills?.[key];
    const recognition = mastery(skill);
    const production = productionMastery(skill);
    const p = ensureEvidenceState(skill?.evidence).production;
    const uncertainty = Math.min(1, posteriorUncertainty(p) * 4.5);
    const novelty = p.attempts === 0 ? 1 : 0;
    const readiness = Math.max(.2, recognition);
    return { interval, score: .42 * (1 - production) + .22 * uncertainty + .18 * novelty + .18 * readiness };
  }).sort((a, b) => b.score - a.score || a.interval.semitones - b.interval.semitones);
  const top = scored.slice(0, 5);
  const floor = Math.min(...top.map((x) => x.score));
  const weights = top.map((x) => Math.max(.05, x.score - floor + .08));
  let r = prng.next() * weights.reduce((a, b) => a + b, 0);
  for (let i = 0; i < top.length; i += 1) { r -= weights[i]; if (r <= 0) return top[i].interval; }
  return top[0].interval;
}

export function makePitchImitationItem(prng, voiceCenterMidi = 60) {
  const offset = prng.int(-5, 5);
  const targetMidi = Math.max(48, Math.min(76, Math.round(voiceCenterMidi + offset)));
  return {
    id: `pitch-imitation:${targetMidi}`,
    family: 'activePitch',
    skillKeys: ['active:pitchImitation'],
    learningAxis: 'production',
    prompt: [{ notes: [targetMidi], duration: .9, gap: .15 }],
    targetMidi,
    targetFrequency: midiToFrequency(targetMidi),
    instruction: 'Écoute la note puis chante-la.',
    actionLabel: 'Écouter puis chanter la note',
    contextTags: ['production:voice', 'task:pitch-imitation']
  };
}

export function makeIntervalSingingItem(progress, prng, voiceCenterMidi = 60) {
  const interval = chooseProductionInterval(progress, prng);
  const ascending = prng.next() < .6;
  const signed = ascending ? interval.semitones : -interval.semitones;
  const rootMidi = Math.round(voiceCenterMidi - signed / 2);
  const targetMidi = rootMidi + signed;
  return {
    id: `interval-sing:${interval.semitones}:${ascending ? 'up' : 'down'}:${rootMidi}`,
    family: 'activeInterval',
    skillKeys: [`interval:${interval.semitones}`],
    learningAxis: 'production',
    prompt: [{ notes: [rootMidi], duration: .85, gap: .15 }],
    rootMidi,
    targetMidi,
    targetFrequency: midiToFrequency(targetMidi),
    instruction: `À partir de la note donnée, chante ${interval.name} ${ascending ? 'ascendante' : 'descendante'}.`,
    actionLabel: `Écouter puis chanter : ${interval.name} ${ascending ? 'ascendante' : 'descendante'}`,
    spokenAnswer: `${interval.name} ${ascending ? 'ascendante' : 'descendante'}`,
    contextTags: ['production:voice', `direction:${ascending ? 'ascending' : 'descending'}`]
  };
}

export function gradeSungPitch(item, estimate, options = {}) {
  if (!estimate?.frequency || (estimate.clarity ?? 0) < (options.minClarity ?? .72)) {
    return { status: 'insufficient', reason: 'signal_instable' };
  }
  const cents = 1200 * Math.log2(estimate.frequency / item.targetFrequency);
  const abs = Math.abs(cents);
  const exact = options.exactCents ?? 35;
  const almost = options.almostCents ?? 70;
  if (abs <= exact) return { status: 'graded', correct: true, grade: 'known', cents, learningAxis: 'production' };
  if (abs <= almost) return { status: 'graded', correct: false, grade: 'almost', cents, learningAxis: 'production' };
  return { status: 'graded', correct: false, grade: 'unknown', cents, learningAxis: 'production' };
}

export function productionGap(progress) {
  const candidates = TRAINABLE_INTERVALS.map((interval) => {
    const skill = progress.skills?.[`interval:${interval.semitones}`];
    const recognition = mastery(skill);
    const production = productionMastery(skill);
    const attempts = ensureEvidenceState(skill?.evidence).production.attempts;
    return { semitones: interval.semitones, name: interval.name, recognition, production, attempts, gap: recognition - production };
  }).filter((x) => x.recognition >= .62).sort((a, b) => b.gap - a.gap || a.attempts - b.attempts);
  return candidates[0] || null;
}
