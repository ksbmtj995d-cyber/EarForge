export function hashString(input) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < input.length; i += 1) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export class PRNG {
  constructor(seed = 1) {
    this.state = (typeof seed === 'number' ? seed : hashString(String(seed))) >>> 0;
    if (this.state === 0) this.state = 0x9e3779b9;
  }

  next() {
    let x = this.state;
    x ^= x << 13;
    x ^= x >>> 17;
    x ^= x << 5;
    this.state = x >>> 0;
    return this.state / 0x100000000;
  }

  int(min, maxInclusive) {
    const span = maxInclusive - min + 1;
    return min + Math.floor(this.next() * span);
  }

  pick(values) {
    if (!values.length) throw new Error('Cannot pick from an empty array');
    return values[this.int(0, values.length - 1)];
  }

  shuffle(values) {
    const copy = [...values];
    for (let i = copy.length - 1; i > 0; i -= 1) {
      const j = this.int(0, i);
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
  }
}
