export const CURRICULUM = [
  { id:'foundations', level:1, title:'Fondations auditives', description:'Hauteur, direction, timbres et premiers intervalles.', goal:'Stabiliser les contrastes auditifs élémentaires avant de nommer des structures plus complexes.', listenFor:'Écoute d’abord la direction et l’écart global, pas le nom de la note.', tip:'Si deux sons te semblent proches, décide d’abord : identiques, plus haut ou plus bas.', families:['pitchDirection','instrumentTimbre','intervalSameDifferent','interval'] },
  { id:'intervals', level:2, title:'Intervalles en profondeur', description:'Ascendants, descendants, harmoniques et comparaison.', goal:'Reconnaître un même intervalle malgré le registre, la direction ou la présentation harmonique.', listenFor:'Cherche la taille de l’écart avant sa couleur émotionnelle ou un morceau-repère.', tip:'Compare les intervalles voisins : seconde majeure contre tierce mineure, quarte contre quinte.', families:['interval','intervalCompare','intervalSameDifferent'] },
  { id:'function', level:3, title:'Oreille fonctionnelle', description:'Entendre les degrés par rapport à une tonalité stabilisée.', goal:'Entendre la fonction d’une note dans un centre tonal plutôt que sa hauteur absolue.', listenFor:'Repère la sensation de repos, tension ou attraction vers la tonique.', tip:'Réentends mentalement la tonique avant de répondre si le contexte tonal s’efface.', families:['scaleDegree','cadence'] },
  { id:'triads', level:4, title:'Accords et basse', description:'Qualités d’accords, basse réelle et renversements.', goal:'Séparer la qualité de l’accord, sa basse et son renversement.', listenFor:'Écoute d’abord la note la plus grave, puis la couleur de l’ensemble.', tip:'Ne déduis pas le renversement uniquement de la couleur : identifie la basse réelle.', families:['chord','chordBass','chordInversion'] },
  { id:'scales', level:5, title:'Gammes et modes', description:'Majeur, mineur, modes, pentatoniques et couleurs scalaires.', goal:'Identifier une organisation scalaire sur plusieurs degrés, pas sur un seul indice.', listenFor:'Repère les demi-tons caractéristiques et la relation finale à la tonique.', tip:'Évite de décider trop tôt : attends le mouvement complet de la gamme.', families:['scale'] },
  { id:'harmony', level:6, title:'Harmonie fonctionnelle', description:'Cadences et progressions, du mouvement local à la fonction.', goal:'Reconnaître des trajectoires harmoniques et leurs fonctions dans le temps.', listenFor:'Suis la direction de la basse et le degré de résolution de chaque accord.', tip:'Après une erreur, réécoute la progression en cherchant uniquement le point de résolution.', families:['cadence','chordProgression','scaleDegree'] },
  { id:'melody', level:7, title:'Mélodie et mémoire', description:'Contour, mémoire tonale, comparaison et détection d’erreurs.', goal:'Maintenir une courte phrase en mémoire puis détecter sa structure ou ses changements.', listenFor:'Encode le contour et quelques points d’ancrage plutôt que chaque note isolément.', tip:'Résume mentalement la phrase en montée, descente, sommet et arrivée.', families:['melodyContour','melodyMemory','errorDetection','interval'] },
  { id:'rhythm', level:8, title:'Rythme et métrique', description:'Reconnaissance, comparaison et organisation métrique.', goal:'Distinguer motif rythmique, pulsation et organisation métrique.', listenFor:'Garde une pulsation interne stable pendant que le motif change.', tip:'Si tu perds le motif, retrouve d’abord les temps forts puis les subdivisions.', families:['rhythm','rhythmCompare','meter'] },
  { id:'intonation', level:9, title:'Justesse et finesse', description:'Détecter les écarts fins de hauteur, puis mesurer séparément la zone limite en cents.', goal:'Affiner la perception des écarts sans confondre entraînement musical et mesure psychophysique.', listenFor:'Concentre-toi sur la direction de dérive et les battements, pas sur le volume.', tip:'La sonde de finesse utilise 16 essais sur son pur autour de La4 et ne modifie jamais ta maîtrise musicale.', families:['tuning','pitchClass'] },
  { id:'integration', level:10, title:'Intégration musicale', description:'Interleaving de fonctions, intervalles, accords, mélodie et rythme.', goal:'Transférer les compétences lorsque le type de problème n’est plus annoncé à l’avance.', listenFor:'Identifie d’abord la dimension pertinente : hauteur, fonction, harmonie, mémoire ou rythme.', tip:'Le but n’est plus de reconnaître un exercice, mais de reconnaître ce que fait la musique.', families:['interval','instrumentTimbre','scaleDegree','chord','chordProgression','scale','cadence','melodyMemory','errorDetection','rhythm','meter','tuning'] }
];

export function chapterById(id){ return CURRICULUM.find(c=>c.id===id) || null; }

export function chapterProgress(progress, chapter, familyMasteryFn){
  const values=chapter.families.map(id=>familyMasteryFn(progress,id)).filter(Number.isFinite);
  const mastery=values.length?values.reduce((a,b)=>a+b,0)/values.length:0;
  return { mastery, attempted: chapter.families.some(id=>(progress.familyStats?.[id]?.attempts||0)>0) };
}

export function adaptiveChapterIndex(progress, familyMasteryFn){
  let highest=0;
  for(let i=0;i<CURRICULUM.length-1;i+=1){
    const row=chapterProgress(progress,CURRICULUM[i],familyMasteryFn);
    if(row.mastery>=0.68 && row.attempted) highest=i+1; else break;
  }
  return Math.min(highest,CURRICULUM.length-1);
}

export function adaptiveFamilies(progress, familyMasteryFn){
  const idx=adaptiveChapterIndex(progress,familyMasteryFn);
  const set=new Set();
  for(let i=0;i<=idx;i+=1) CURRICULUM[i].families.forEach(x=>set.add(x));
  if(idx<CURRICULUM.length-1) CURRICULUM[idx+1].families.slice(0,2).forEach(x=>set.add(x));
  return [...set];
}
