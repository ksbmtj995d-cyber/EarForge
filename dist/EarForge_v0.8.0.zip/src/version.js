export const APP_VERSION = '0.8.0';
export const STATE_SCHEMA_VERSION = 7;
export const CACHE_VERSION = 'earforge-shell-v8';
