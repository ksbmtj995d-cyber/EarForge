const EPSILON = 1e-12;

export function centsBetween(frequency, referenceFrequency) {
  if (!(frequency > 0) || !(referenceFrequency > 0)) return Number.NaN;
  return 1200 * Math.log2(frequency / referenceFrequency);
}

export function frequencyToMidi(frequency) {
  if (!(frequency > 0)) return Number.NaN;
  return 69 + 12 * Math.log2(frequency / 440);
}

export function midiToNearestPitch(frequency) {
  const midiFloat = frequencyToMidi(frequency);
  if (!Number.isFinite(midiFloat)) return null;
  const midi = Math.round(midiFloat);
  return { midi, cents: (midiFloat - midi) * 100 };
}

function decimateAndCenter(samples, factor) {
  const step = Math.max(1, Math.floor(factor || 1));
  const length = Math.floor(samples.length / step);
  const out = new Float64Array(length);
  let mean = 0;
  for (let i = 0; i < length; i += 1) {
    const value = Number(samples[i * step]) || 0;
    out[i] = value;
    mean += value;
  }
  mean /= Math.max(1, length);
  for (let i = 0; i < length; i += 1) out[i] -= mean;
  return out;
}

export function estimatePitchYin(samples, sampleRate, options = {}) {
  const minFrequency = options.minFrequency ?? 80;
  const maxFrequency = options.maxFrequency ?? 1000;
  const threshold = options.threshold ?? 0.12;
  const decimate = options.decimate ?? (sampleRate >= 40000 ? 2 : 1);
  if (!samples || samples.length < 256 || !(sampleRate > 0)) return null;

  const signal = decimateAndCenter(samples, decimate);
  const effectiveRate = sampleRate / Math.max(1, Math.floor(decimate));
  const maxTau = Math.min(Math.floor(effectiveRate / minFrequency), Math.floor(signal.length / 2) - 1);
  const minTau = Math.max(2, Math.floor(effectiveRate / maxFrequency));
  if (!(maxTau > minTau + 2)) return null;

  const windowLength = signal.length - maxTau;
  let energy = 0;
  for (let i = 0; i < windowLength; i += 1) energy += signal[i] * signal[i];
  if (energy / Math.max(1, windowLength) < 1e-7) return null;

  const difference = new Float64Array(maxTau + 1);
  for (let tau = 1; tau <= maxTau; tau += 1) {
    let sum = 0;
    for (let i = 0; i < windowLength; i += 1) {
      const delta = signal[i] - signal[i + tau];
      sum += delta * delta;
    }
    difference[tau] = sum;
  }

  const normalized = new Float64Array(maxTau + 1);
  normalized[0] = 1;
  let running = 0;
  for (let tau = 1; tau <= maxTau; tau += 1) {
    running += difference[tau];
    normalized[tau] = running > EPSILON ? (difference[tau] * tau) / running : 1;
  }

  let tau = -1;
  for (let candidate = minTau; candidate < maxTau; candidate += 1) {
    if (normalized[candidate] < threshold) {
      tau = candidate;
      while (tau + 1 <= maxTau && normalized[tau + 1] < normalized[tau]) tau += 1;
      break;
    }
  }
  if (tau < 0) {
    let bestValue = Number.POSITIVE_INFINITY;
    for (let candidate = minTau; candidate <= maxTau; candidate += 1) {
      if (normalized[candidate] < bestValue) {
        bestValue = normalized[candidate];
        tau = candidate;
      }
    }
    if (tau < 0 || bestValue > 0.35) return null;
  }

  let refinedTau = tau;
  if (tau > 1 && tau < maxTau) {
    const left = normalized[tau - 1];
    const center = normalized[tau];
    const right = normalized[tau + 1];
    const denominator = left - 2 * center + right;
    if (Math.abs(denominator) > EPSILON) {
      const correction = 0.5 * (left - right) / denominator;
      if (Math.abs(correction) <= 1) refinedTau = tau + correction;
    }
  }

  const frequency = effectiveRate / refinedTau;
  const clarity = Math.max(0, Math.min(1, 1 - normalized[tau]));
  if (!(frequency >= minFrequency && frequency <= maxFrequency)) return null;
  return { frequency, clarity, period: refinedTau, algorithm: 'yin' };
}

// Deliberately simpler rival used in sealed experiments; not used by the product runtime.
export function estimatePitchAutocorrelation(samples, sampleRate, options = {}) {
  const minFrequency = options.minFrequency ?? 80;
  const maxFrequency = options.maxFrequency ?? 1000;
  const decimate = options.decimate ?? (sampleRate >= 40000 ? 2 : 1);
  if (!samples || samples.length < 256 || !(sampleRate > 0)) return null;
  const signal = decimateAndCenter(samples, decimate);
  const effectiveRate = sampleRate / Math.max(1, Math.floor(decimate));
  const maxTau = Math.min(Math.floor(effectiveRate / minFrequency), Math.floor(signal.length / 2) - 1);
  const minTau = Math.max(2, Math.floor(effectiveRate / maxFrequency));
  const windowLength = signal.length - maxTau;
  let bestCorrelation = -1;
  let bestTau = -1;
  for (let tau = minTau; tau <= maxTau; tau += 1) {
    let aa = 0; let bb = 0; let ab = 0;
    for (let i = 0; i < windowLength; i += 1) {
      const a = signal[i]; const b = signal[i + tau];
      aa += a * a; bb += b * b; ab += a * b;
    }
    const correlation = ab / (Math.sqrt(aa * bb) + EPSILON);
    if (correlation > bestCorrelation) { bestCorrelation = correlation; bestTau = tau; }
  }
  if (bestTau < 0 || bestCorrelation < 0.25) return null;
  return { frequency: effectiveRate / bestTau, clarity: Math.max(0, Math.min(1, bestCorrelation)), period: bestTau, algorithm: 'autocorrelation' };
}

export function robustPitchEstimate(estimates, options = {}) {
  const minClarity = options.minClarity ?? 0.72;
  const maxSpreadCents = options.maxSpreadCents ?? 45;
  const valid = (estimates || []).filter((x) => x?.frequency > 0 && (x.clarity ?? 0) >= minClarity);
  if (valid.length < (options.minFrames ?? 4)) return null;
  const sorted = valid.map((x) => x.frequency).sort((a, b) => a - b);
  const median = sorted[Math.floor(sorted.length / 2)];
  const cents = sorted.map((frequency) => centsBetween(frequency, median)).sort((a, b) => a - b);
  const lower = cents[Math.floor(cents.length * 0.2)];
  const upper = cents[Math.floor((cents.length - 1) * 0.8)];
  if (upper - lower > maxSpreadCents) return null;
  const clarity = valid.reduce((sum, x) => sum + x.clarity, 0) / valid.length;
  return { frequency: median, clarity, frames: valid.length, spreadCents: upper - lower };
}
