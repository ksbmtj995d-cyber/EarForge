export const NOTE_NAMES_FR = ['do', 'do dièse', 'ré', 'mi bémol', 'mi', 'fa', 'fa dièse', 'sol', 'la bémol', 'la', 'si bémol', 'si'];

export const INTERVALS = [
  ['unisson', 0], ['seconde mineure', 1], ['seconde majeure', 2], ['tierce mineure', 3],
  ['tierce majeure', 4], ['quarte juste', 5], ['triton', 6], ['quinte juste', 7],
  ['sixte mineure', 8], ['sixte majeure', 9], ['septième mineure', 10], ['septième majeure', 11], ['octave', 12],
  ['neuvième mineure', 13], ['neuvième majeure', 14], ['dixième mineure', 15], ['dixième majeure', 16]
].map(([name, semitones]) => ({ name, semitones }));

export const SCALES = {
  'majeure': [0, 2, 4, 5, 7, 9, 11, 12],
  'mineure naturelle': [0, 2, 3, 5, 7, 8, 10, 12],
  'mineure harmonique': [0, 2, 3, 5, 7, 8, 11, 12],
  'mineure mélodique': [0, 2, 3, 5, 7, 9, 11, 12],
  'dorien': [0, 2, 3, 5, 7, 9, 10, 12],
  'phrygien': [0, 1, 3, 5, 7, 8, 10, 12],
  'lydien': [0, 2, 4, 6, 7, 9, 11, 12],
  'mixolydien': [0, 2, 4, 5, 7, 9, 10, 12],
  'locrien': [0, 1, 3, 5, 6, 8, 10, 12],
  'pentatonique majeure': [0, 2, 4, 7, 9, 12],
  'pentatonique mineure': [0, 3, 5, 7, 10, 12],
  'blues mineure': [0, 3, 5, 6, 7, 10, 12],
  'par tons': [0, 2, 4, 6, 8, 10, 12],
  'chromatique': Array.from({ length: 13 }, (_, i) => i)
};

export const CHORDS = {
  'majeur': [0, 4, 7], 'mineur': [0, 3, 7], 'diminué': [0, 3, 6], 'augmenté': [0, 4, 8],
  'sus2': [0, 2, 7], 'sus4': [0, 5, 7], 'majeur sixte': [0, 4, 7, 9], 'mineur sixte': [0, 3, 7, 9],
  'majeur septième': [0, 4, 7, 11], 'septième de dominante': [0, 4, 7, 10], 'mineur septième': [0, 3, 7, 10],
  'demi-diminué': [0, 3, 6, 10], 'septième diminuée': [0, 3, 6, 9]
};

export const CADENCES = {
  'parfaite': [[0, 4, 7], [-5, -1, 2], [0, 4, 7]],
  'plagale': [[0, 4, 7], [-7, -3, 0], [0, 4, 7]],
  'demi-cadence': [[0, 4, 7], [-3, 0, 4], [-5, -1, 2]],
  'rompue': [[0, 4, 7], [-5, -1, 2], [-3, 0, 4]]
};

export const PROGRESSIONS = {
  'I–IV–V–I': [[0,4,7],[5,9,12],[7,11,14],[0,4,7]],
  'I–V–vi–IV': [[0,4,7],[7,11,14],[9,12,16],[5,9,12]],
  'ii–V–I': [[2,5,9],[7,11,14],[0,4,7]],
  'I–vi–IV–V': [[0,4,7],[9,12,16],[5,9,12],[7,11,14]],
  'vi–IV–I–V': [[9,12,16],[5,9,12],[0,4,7],[7,11,14]],
  'I–IV–ii–V': [[0,4,7],[5,9,12],[2,5,9],[7,11,14]]
};

export const DEGREE_LABELS = ['tonique, premier degré', 'sus-tonique, deuxième degré', 'médiante, troisième degré', 'sous-dominante, quatrième degré', 'dominante, cinquième degré', 'sus-dominante, sixième degré', 'sensible, septième degré'];

export function midiToFrequency(midi) { return 440 * (2 ** ((midi - 69) / 12)); }
export function clampMidi(midi, min = 48, max = 84) { let v=midi; while(v<min)v+=12; while(v>max)v-=12; return v; }
export function transpose(rootMidi, offsets) { return offsets.map((offset) => rootMidi + offset); }
export function invertChord(notes, inversion = 0) { const r=[...notes]; for(let i=0;i<inversion;i+=1){const x=r.shift();r.push(x+12);} return r; }
export function noteNameFr(midi) { return NOTE_NAMES_FR[((Math.round(midi) % 12) + 12) % 12]; }
export function majorDegreeMidi(tonic, degree) { return tonic + [0,2,4,5,7,9,11][Math.max(0,Math.min(6,degree-1))]; }
