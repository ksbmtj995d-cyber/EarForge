import { estimatePitchYin, robustPitchEstimate } from './pitch.js';

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export function microphoneErrorCode(error) {
  const name = error?.name || '';
  if (name === 'NotAllowedError' || name === 'SecurityError') return 'permission_denied';
  if (name === 'NotFoundError' || name === 'DevicesNotFoundError') return 'no_microphone';
  if (name === 'NotReadableError' || name === 'AbortError') return 'device_unavailable';
  return 'microphone_error';
}

export class MicrophonePitchInput {
  constructor({ mediaDevices = globalThis.navigator?.mediaDevices, contextProvider } = {}) {
    this.mediaDevices = mediaDevices;
    this.contextProvider = contextProvider;
    this.stream = null;
    this.source = null;
    this.analyser = null;
    this.buffer = null;
    this.health = 'idle';
    this.lastError = null;
  }

  async start() {
    if (!this.mediaDevices?.getUserMedia) throw Object.assign(new Error('Microphone Web indisponible.'), { code: 'unsupported' });
    if (this.health === 'ready' && this.stream?.active) return this;
    await this.stop();
    try {
      const context = await this.contextProvider?.();
      if (!context) throw new Error('Contexte audio indisponible.');
      const stream = await this.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false }, video: false });
      const source = context.createMediaStreamSource(stream);
      const analyser = context.createAnalyser();
      analyser.fftSize = 4096;
      analyser.smoothingTimeConstant = 0;
      source.connect(analyser);
      this.stream = stream; this.source = source; this.analyser = analyser; this.buffer = new Float32Array(analyser.fftSize); this.health = 'ready'; this.lastError = null;
      for (const track of stream.getAudioTracks?.() || []) {
        track.addEventListener?.('ended', () => { this.health = 'ended'; }, { once: true });
      }
      return this;
    } catch (error) {
      this.lastError = error; this.health = 'error';
      error.code ||= microphoneErrorCode(error);
      throw error;
    }
  }

  sample() {
    if (this.health !== 'ready' || !this.analyser || !this.buffer || this.stream?.active === false) return null;
    this.analyser.getFloatTimeDomainData(this.buffer);
    return estimatePitchYin(this.buffer, this.analyser.context?.sampleRate || 48000, { minFrequency: 80, maxFrequency: 1000 });
  }

  async captureStable({ timeoutMs = 4200, intervalMs = 85, minFrames = 5, signal } = {}) {
    await this.start();
    const started = performance.now();
    const estimates = [];
    while (performance.now() - started < timeoutMs) {
      if (signal?.aborted) return { status: 'aborted' };
      if (this.health !== 'ready' || this.stream?.active === false) return { status: 'stream_ended' };
      const estimate = this.sample();
      if (estimate) estimates.push(estimate);
      const robust = robustPitchEstimate(estimates.slice(-10), { minFrames, minClarity: .72, maxSpreadCents: 48 });
      if (robust) return { status: 'ok', ...robust };
      await sleep(intervalMs);
    }
    return { status: 'timeout', frames: estimates.length };
  }

  async stop() {
    try { this.source?.disconnect?.(); } catch {}
    for (const track of this.stream?.getTracks?.() || []) { try { track.stop(); } catch {} }
    this.stream = null; this.source = null; this.analyser = null; this.buffer = null;
    if (this.health !== 'error') this.health = 'idle';
  }

  async recover() { await this.stop(); return this.start(); }
}
