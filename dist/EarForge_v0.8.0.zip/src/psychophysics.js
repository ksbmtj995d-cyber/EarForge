// EarForge V0.7 — browser-local psychophysical pitch-direction threshold estimator.
// This measurement is deliberately separate from musical mastery. It never uses response latency.

export const PITCH_JND_TARGET_CORRECT = 0.794;
export const PITCH_JND_TRIALS = 16;
export const PITCH_JND_REFERENCE_MIDI = 69; // A4. Keep the reference controlled; do not generalize this threshold to all registers/timbres.
export const PITCH_JND_MIN_CENTS = 2;
export const PITCH_JND_MAX_CENTS = 60;
export const PITCH_JND_HISTORY_LIMIT = 24;

const TARGET_LOGIT=Math.log(((PITCH_JND_TARGET_CORRECT-.5)/.5)/(1-((PITCH_JND_TARGET_CORRECT-.5)/.5)));
const THRESHOLD_GRID=Array.from({length:37},(_,i)=>PITCH_JND_MIN_CENTS*Math.pow(PITCH_JND_MAX_CENTS/PITCH_JND_MIN_CENTS,i/36));
const STIMULUS_GRID=Array.from({length:31},(_,i)=>PITCH_JND_MIN_CENTS*Math.pow(PITCH_JND_MAX_CENTS/PITCH_JND_MIN_CENTS,i/30));
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const sigmoid=x=>1/(1+Math.exp(-x));

function psychometricProbability(deltaCents,thresholdCents,slope=3,lapse=.02){
  const s=sigmoid(slope*Math.log(Math.max(.0001,deltaCents)/thresholdCents)+TARGET_LOGIT);
  return clamp(.5+(.5-lapse)*s,.50001,.99999);
}
const MODEL_PROBS=STIMULUS_GRID.map(d=>THRESHOLD_GRID.map(t=>psychometricProbability(d,t)));

function normalize(weights){let z=0;for(const x of weights)z+=x;if(!z)z=1;return weights.map(x=>x/z);}
function entropy(weights){let h=0;for(const x of weights)if(x>0)h-=x*Math.log(x);return h;}
function prior(){const center=Math.log(12),sd=.95;return normalize(THRESHOLD_GRID.map(t=>Math.exp(-.5*((Math.log(t)-center)/sd)**2)));}
function posterior(observations=[]){
  let weights=prior();
  for(const o of observations){
    const d=clamp(Number(o?.deltaCents)||PITCH_JND_MAX_CENTS,PITCH_JND_MIN_CENTS,PITCH_JND_MAX_CENTS);
    let best=0,bestDist=Infinity;for(let i=0;i<STIMULUS_GRID.length;i++){const dist=Math.abs(Math.log(STIMULUS_GRID[i]/d));if(dist<bestDist){bestDist=dist;best=i;}}
    const probs=MODEL_PROBS[best];weights=normalize(weights.map((w,i)=>w*(o?.correct?probs[i]:1-probs[i])));
  }
  return weights;
}
function posteriorSummary(weights){
  let meanLog=0;for(let i=0;i<weights.length;i++)meanLog+=weights[i]*Math.log(THRESHOLD_GRID[i]);
  let variance=0;for(let i=0;i<weights.length;i++)variance+=weights[i]*(Math.log(THRESHOLD_GRID[i])-meanLog)**2;
  const estimate=Math.exp(meanLog),logSd=Math.sqrt(Math.max(0,variance)),factor=Math.exp(1.96*logSd);
  return {estimateCents:estimate,logSd,lower95Cents:Math.max(PITCH_JND_MIN_CENTS,estimate/factor),upper95Cents:Math.min(PITCH_JND_MAX_CENTS,estimate*factor)};
}
function chooseStimulus(weights){
  let bestIndex=0,bestEntropy=Infinity;
  for(let di=0;di<STIMULUS_GRID.length;di++){
    const probs=MODEL_PROBS[di];let pCorrect=0;for(let i=0;i<weights.length;i++)pCorrect+=weights[i]*probs[i];
    const zCorrect=pCorrect||1,zWrong=(1-pCorrect)||1;let hCorrect=0,hWrong=0;
    for(let i=0;i<weights.length;i++){
      const a=weights[i]*probs[i]/zCorrect,b=weights[i]*(1-probs[i])/zWrong;
      if(a>0)hCorrect-=a*Math.log(a);if(b>0)hWrong-=b*Math.log(b);
    }
    const expected=pCorrect*hCorrect+(1-pCorrect)*hWrong;
    if(expected<bestEntropy){bestEntropy=expected;bestIndex=di;}
  }
  return STIMULUS_GRID[bestIndex];
}
function xorshift32(seed){let x=(seed>>>0)||1;x^=x<<13;x^=x>>>17;x^=x<<5;return x>>>0;}
function trialWord(seed,index,salt){return xorshift32((seed>>>0)^Math.imul(index+1,0x9e3779b1)^salt);}
function cleanObservation(o){const d=Number(o?.deltaCents),at=Number(o?.at);if(!Number.isFinite(d)||d<PITCH_JND_MIN_CENTS||d>PITCH_JND_MAX_CENTS)return null;return {deltaCents:d,correct:Boolean(o.correct),at:Number.isFinite(at)?at:0};}

export function createPsychophysicsProgress(){return {pitchJnd:{current:null,history:[]}};}
export function ensurePsychophysicsProgress(value){
  const source=value&&typeof value==='object'?value:{};const pj=source.pitchJnd&&typeof source.pitchJnd==='object'?source.pitchJnd:{};
  let current=null;if(pj.current&&typeof pj.current==='object')current=ensurePitchJndRun(pj.current);
  const history=Array.isArray(pj.history)?pj.history.filter(x=>x&&Number.isFinite(Number(x.estimateCents))).slice(-PITCH_JND_HISTORY_LIMIT).map(x=>({startedAt:Number(x.startedAt)||0,completedAt:Number(x.completedAt)||0,trials:Math.max(0,Math.min(PITCH_JND_TRIALS,Number(x.trials)||0)),estimateCents:clamp(Number(x.estimateCents),PITCH_JND_MIN_CENTS,PITCH_JND_MAX_CENTS),logSd:Math.max(0,Number(x.logSd)||0),lower95Cents:clamp(Number(x.lower95Cents)||PITCH_JND_MIN_CENTS,PITCH_JND_MIN_CENTS,PITCH_JND_MAX_CENTS),upper95Cents:clamp(Number(x.upper95Cents)||PITCH_JND_MAX_CENTS,PITCH_JND_MIN_CENTS,PITCH_JND_MAX_CENTS),referenceMidi:Number(x.referenceMidi)||PITCH_JND_REFERENCE_MIDI,method:'bayesian-entropy-2afc-v1'})):[];
  if(current?.observations?.length>=PITCH_JND_TRIALS)current=null;
  return {pitchJnd:{current,history}};
}
export function createPitchJndRun({seed=Date.now(),startedAt=Date.now()}={}){return {version:1,seed:(Number(seed)>>>0)||1,startedAt:Number(startedAt)||Date.now(),observations:[],referenceMidi:PITCH_JND_REFERENCE_MIDI,method:'bayesian-entropy-2afc-v1'};}
export function ensurePitchJndRun(value){
  const v=value&&typeof value==='object'?value:{};return {version:1,seed:(Number(v.seed)>>>0)||1,startedAt:Number(v.startedAt)||Date.now(),observations:(Array.isArray(v.observations)?v.observations.map(cleanObservation).filter(Boolean):[]).slice(0,PITCH_JND_TRIALS),referenceMidi:PITCH_JND_REFERENCE_MIDI,method:'bayesian-entropy-2afc-v1'};
}
export function pitchJndSummary(run){const safe=ensurePitchJndRun(run),weights=posterior(safe.observations);return {...posteriorSummary(weights),trials:safe.observations.length,remaining:Math.max(0,PITCH_JND_TRIALS-safe.observations.length),complete:safe.observations.length>=PITCH_JND_TRIALS,referenceMidi:PITCH_JND_REFERENCE_MIDI};}
export function nextPitchJndTrial(run){
  const safe=ensurePitchJndRun(run);if(safe.observations.length>=PITCH_JND_TRIALS)return null;
  const weights=posterior(safe.observations),deltaCents=chooseStimulus(weights),index=safe.observations.length;
  const sign=(trialWord(safe.seed,index,0x7f4a7c15)&1)?1:-1,signedDeltaCents=sign*deltaCents;
  return {index,number:index+1,total:PITCH_JND_TRIALS,deltaCents,signedDeltaCents,answer:sign>0?'higher':'lower',referenceMidi:PITCH_JND_REFERENCE_MIDI,prompt:[{notes:[PITCH_JND_REFERENCE_MIDI],duration:.58,gap:.16},{notes:[PITCH_JND_REFERENCE_MIDI],duration:.72,gap:.04,detuneCents:signedDeltaCents}],timbreOverride:'sine'};
}
export function updatePitchJndRun(run,trial,choice,now=Date.now()){
  const safe=ensurePitchJndRun(run);if(safe.observations.length>=PITCH_JND_TRIALS)throw new Error('Mesure déjà terminée.');
  if(!trial||trial.index!==safe.observations.length)throw new Error('Essai psychophysique incohérent.');
  if(!['higher','lower'].includes(choice))throw new Error('Réponse psychophysique invalide.');
  const correct=choice===trial.answer;safe.observations.push({deltaCents:clamp(Math.abs(Number(trial.deltaCents)),PITCH_JND_MIN_CENTS,PITCH_JND_MAX_CENTS),correct,at:Number(now)||Date.now()});
  return {run:safe,correct,summary:pitchJndSummary(safe)};
}
export function finalizePitchJndMeasurement(psychophysics,run,now=Date.now()){
  const state=ensurePsychophysicsProgress(psychophysics),safe=ensurePitchJndRun(run),summary=pitchJndSummary(safe);if(!summary.complete)throw new Error('Mesure psychophysique incomplète.');
  const record={startedAt:safe.startedAt,completedAt:Number(now)||Date.now(),trials:summary.trials,estimateCents:summary.estimateCents,logSd:summary.logSd,lower95Cents:summary.lower95Cents,upper95Cents:summary.upper95Cents,referenceMidi:PITCH_JND_REFERENCE_MIDI,method:safe.method};
  state.pitchJnd.history=[...state.pitchJnd.history,record].slice(-PITCH_JND_HISTORY_LIMIT);state.pitchJnd.current=null;return {psychophysics:state,record};
}
export function latestPitchJndMeasurement(progressOrPsychophysics){const p=progressOrPsychophysics?.psychophysics?.pitchJnd?progressOrPsychophysics.psychophysics:progressOrPsychophysics;const state=ensurePsychophysicsProgress(p),h=state.pitchJnd.history;return h.length?h[h.length-1]:null;}
export function pitchJndMeasurementDue(progress,now=Date.now(),minRecognitionAttempts=60,maxAgeDays=45){const latest=latestPitchJndMeasurement(progress);if((progress?.totalAttempts||0)<minRecognitionAttempts)return false;if(!latest)return true;return Number(now)-Number(latest.completedAt||0)>maxAgeDays*86400000;}

// Exposed for deterministic tests/research; not a user-facing score.
export const _psychophysicsInternals={THRESHOLD_GRID,STIMULUS_GRID,psychometricProbability,posterior,chooseStimulus};
