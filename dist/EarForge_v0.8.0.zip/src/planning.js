import { CURRICULUM, adaptiveChapterIndex } from './curriculum.js';
import { familyMastery, mastery, productionMastery, transferMastery } from './scheduler.js';
import { forgettingProbeNeed, forgettingSummary } from './forgetting.js';
import { transferProbeNeed } from './transfer.js';
import { latestPitchJndMeasurement, pitchJndMeasurementDue } from './psychophysics.js';

function dayKey(ts){const d=new Date(ts);return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`;}
export function sessionsToday(progress,now=Date.now()){const key=dayKey(now);return (progress.history||[]).filter(x=>x?.endedAt&&dayKey(x.endedAt)===key);}
export function activeDaysLast7(progress,now=Date.now()){const floor=now-6*86400000;return new Set((progress.history||[]).filter(x=>x?.endedAt>=floor&&x.endedAt<=now).map(x=>dayKey(x.endedAt))).size;}
export function dueSkills(progress,now=Date.now()){return Object.entries(progress.skills||{}).filter(([,s])=>(s.attempts||0)>0&&s.nextDueAt>0&&s.nextDueAt<=now).sort((a,b)=>(a[1].nextDueAt||0)-(b[1].nextDueAt||0));}
export function weakestSkills(progress,limit=5){return Object.entries(progress.skills||{}).filter(([,s])=>(s.attempts||0)>0).sort((a,b)=>mastery(a[1])-mastery(b[1])).slice(0,limit);}
export function retentionDueSkills(progress,now=Date.now(),threshold=.55){return Object.entries(progress.skills||{}).filter(([,s])=>(s.attempts||0)>0&&forgettingProbeNeed(s,now)>=threshold).sort((a,b)=>forgettingProbeNeed(b[1],now)-forgettingProbeNeed(a[1],now));}
export function productionGapSkills(progress,limit=5){return Object.entries(progress.skills||{}).map(([key,s])=>({key,s,recognition:mastery(s),production:productionMastery(s),productionAttempts:s.evidence?.production?.attempts||0})).filter(x=>x.key.startsWith('interval:')&&x.recognition>=.62).map(x=>({...x,gap:x.recognition-x.production})).sort((a,b)=>b.gap-a.gap||a.productionAttempts-b.productionAttempts).slice(0,limit);}


export function transferGapSkills(progress,limit=5){return Object.entries(progress.skills||{}).map(([key,s])=>({key,s,recognition:mastery(s),transfer:transferMastery(s),transferAttempts:s.evidence?.transfer?.attempts||0,need:transferProbeNeed(s)})).filter(x=>x.recognition>=.62&&x.need>0).map(x=>({...x,gap:x.recognition-x.transfer})).sort((a,b)=>b.need-a.need||b.gap-a.gap).slice(0,limit);}
export function memoryCalibration(progress,now=Date.now()){const rows=Object.values(progress.skills||{}).filter(s=>(s.evidence?.forgetting?.observations?.length||0)>0).map(s=>forgettingSummary(s,now));const stabilities=rows.map(x=>x.stabilityDays).sort((a,b)=>a-b);return{skills:rows.length,medianStabilityDays:stabilities.length?stabilities[Math.floor((stabilities.length-1)/2)]:null,meanPredictedRecall:rows.length?rows.reduce((sum,x)=>sum+(x.predictedRecall??0),0)/rows.length:null};}

export function buildDailyPlan(progress,settings={},now=Date.now()){
  const due=dueSkills(progress,now), retentionDue=retentionDueSkills(progress,now), productionGaps=productionGapSkills(progress,3), transferGaps=transferGapSkills(progress,3), memory=memoryCalibration(progress,now), weak=weakestSkills(progress,3), chapterIndex=adaptiveChapterIndex(progress,familyMastery), chapter=CURRICULUM[chapterIndex], pitchJnd=latestPitchJndMeasurement(progress), pitchJndDue=pitchJndMeasurementDue(progress,now);
  const today=sessionsToday(progress,now), base=Math.min(30,Math.max(5,Number(settings.dailyTargetMinutes)||10));
  const recommendedMinutes=base;
  const lastBackup=Date.parse(settings.lastBackupAt||'')||0;
  const backupDue=(progress.sessionsCompleted||0)>=2&&(!lastBackup||now-lastBackup>14*86400000);
  let nudge;
  if(backupDue)nudge={kind:'backup',text:'Sauvegarde conseillée : exporte une copie portable de ta progression.',action:'Exporter'};
  else if(retentionDue.length)nudge={kind:'retention',text:`${retentionDue.length} preuve${retentionDue.length>1?'s':''} de rétention retardée${retentionDue.length>1?'s':''} est${retentionDue.length>1?'sont':''} prête${retentionDue.length>1?'s':''} à être sondée${retentionDue.length>1?'s':''}.`,action:'Réviser'};
  else if(due.length)nudge={kind:'review',text:`${due.length} compétence${due.length>1?'s':''} arrivée${due.length>1?'s':''} à échéance de révision.`,action:'Réviser'};
  else if((progress.totalAttempts||0)>=40&&transferGaps.length&&(progress.totalTransferAttempts||0)<Math.max(5,(progress.totalAttempts||0)*.09))nudge={kind:'transfer',text:'La reconnaissance est assez solide pour vérifier qu’elle survit à un changement de timbre.',action:'Sonder'};
  else if((progress.totalAttempts||0)>=30&&productionGaps.length&&(progress.totalProductionAttempts||0)<Math.max(4,(progress.totalAttempts||0)*.08))nudge={kind:'production',text:'La reconnaissance progresse plus vite que la production chantée. Une courte sonde vocale peut compléter le profil.',action:'Produire'};
  else if(pitchJndDue)nudge={kind:'measurement',text:'Une mesure descriptive de finesse en cents est disponible. Elle reste séparée de la maîtrise musicale.',action:'Mesurer'};
  else if(!today.length)nudge={kind:'practice',text:`Une séance de ${recommendedMinutes} min suffit pour maintenir le cycle de révision aujourd’hui.`,action:'Commencer'};
  else nudge={kind:'done',text:'Le travail prévu aujourd’hui est enregistré. Le moteur préparera la prochaine échéance.',action:null};
  return {date:dayKey(now),targetMinutes:base,recommendedMinutes,dueCount:due.length,retentionDueCount:retentionDue.length,productionGap:productionGaps[0]||null,transferGap:transferGaps[0]||null,memory,weakSkills:weak.map(([key,s])=>({key,mastery:mastery(s)})),chapterIndex,chapterTitle:chapter?.title||'',sessionsToday:today.length,minutesToday:today.reduce((sum,x)=>sum+(Number(x.elapsedMinutes)||Number(x.durationMinutes)||0),0),activeDays7:activeDaysLast7(progress,now),backupDue,pitchJnd,pitchJndDue,nudge};
}

export function buildWeeklyPlan(progress,settings={},now=Date.now()){
  const buckets=Array.from({length:7},(_,i)=>({offset:i,date:dayKey(now+i*86400000),due:0,retention:0,recommendedMinutes:Math.min(30,Math.max(5,Number(settings.dailyTargetMinutes)||10))}));
  for(const s of Object.values(progress.skills||{})){
    if(!(s.attempts||0)||!s.nextDueAt)continue;
    const diff=Math.floor((new Date(s.nextDueAt).setHours(0,0,0,0)-new Date(now).setHours(0,0,0,0))/86400000);
    if(diff>=0&&diff<7)buckets[diff].due+=1;
  }
  for(const [key,s] of Object.entries(progress.skills||{})){if(!(s.attempts||0))continue;for(let i=0;i<7;i+=1){const t=now+i*86400000;if(forgettingProbeNeed(s,t)>=.55){buckets[i].retention+=1;break;}}}
  return buckets;
}
