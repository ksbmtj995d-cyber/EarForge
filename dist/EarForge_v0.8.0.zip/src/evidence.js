import { addForgettingObservation, createForgettingState, ensureForgettingState } from './forgetting.js';
const HOUR = 3_600_000;
const DAY = 24 * HOUR;

export const LEARNING_AXES = ['recognition', 'production', 'transfer'];
export const RETENTION_BANDS = Object.freeze({
  d1: { id: 'd1', minMs: 18 * HOUR, label: 'J+1' },
  d7: { id: 'd7', minMs: 5 * DAY, label: 'J+7' },
  d30: { id: 'd30', minMs: 21 * DAY, label: 'J+30' }
});

export function createPosterior() {
  return { attempts: 0, correct: 0, alpha: 2, beta: 2, lastSeenAt: 0, lapses: 0 };
}

export function createEvidenceState() {
  return {
    production: createPosterior(),
    transfer: createPosterior(),
    retention: { d1: createPosterior(), d7: createPosterior(), d30: createPosterior() },
    forgetting: createForgettingState()
  };
}

function copyPosterior(value) { return { ...createPosterior(), ...(value || {}) }; }

export function ensureEvidenceState(value) {
  const e = value && typeof value === 'object' ? value : {};
  return {
    production: copyPosterior(e.production),
    transfer: copyPosterior(e.transfer),
    retention: {
      d1: copyPosterior(e.retention?.d1),
      d7: copyPosterior(e.retention?.d7),
      d30: copyPosterior(e.retention?.d30)
    },
    forgetting: ensureForgettingState(e.forgetting)
  };
}

export function posteriorMastery(posterior) {
  const p = copyPosterior(posterior);
  return p.alpha / (p.alpha + p.beta);
}

export function posteriorUncertainty(posterior) {
  const p = copyPosterior(posterior);
  const sum = p.alpha + p.beta;
  return Math.sqrt((p.alpha * p.beta) / ((sum * sum) * (sum + 1)));
}

export function resultWeight(result) {
  if (result?.grade === 'known') return 1.15;
  if (result?.grade === 'almost') return 0.35;
  if (result?.grade === 'unknown') return -1.05;
  return result?.correct === true ? 1 : -1;
}

export function isStrictResult(result) { return result?.correct === true || result?.grade === 'known'; }
export function isPositiveResult(result) { return isStrictResult(result) || result?.grade === 'almost'; }

export function updatePosterior(posterior, result, now = Date.now()) {
  const p = copyPosterior(posterior);
  const weight = resultWeight(result);
  p.attempts += 1;
  if (weight > 0) {
    if (isStrictResult(result)) p.correct += 1;
    p.alpha += weight;
  } else {
    p.beta += Math.abs(weight);
    p.lapses += 1;
  }
  p.lastSeenAt = now;
  return p;
}

export function retentionBandForDelay(delayMs) {
  if (!(delayMs >= RETENTION_BANDS.d1.minMs)) return null;
  if (delayMs >= RETENTION_BANDS.d30.minMs) return 'd30';
  if (delayMs >= RETENTION_BANDS.d7.minMs) return 'd7';
  return 'd1';
}

export function updateRetentionBand(evidence, delayMs, result, now = Date.now()) {
  const next = ensureEvidenceState(evidence);
  const band = retentionBandForDelay(delayMs);
  if (!band) return { evidence: next, band: null };
  next.retention[band] = updatePosterior(next.retention[band], result, now);
  return { evidence: next, band };
}


export function updateForgettingEvidence(evidence, delayMs, result, now = Date.now()) {
  const next = ensureEvidenceState(evidence);
  const updated = addForgettingObservation(next.forgetting, delayMs, result, now);
  next.forgetting = updated.state;
  return { evidence: next, recorded: updated.recorded };
}

export function retentionProbeNeed(skill, now = Date.now()) {
  const last = skill?.lastRecognitionAt || skill?.lastSeenAt || 0;
  if (!last) return 0;
  const band = retentionBandForDelay(now - last);
  if (!band) return 0;
  const posterior = ensureEvidenceState(skill?.evidence).retention[band];
  const coverageNeed = Math.max(0, 1 - Math.min(1, posterior.attempts / 3));
  const uncertaintyNeed = Math.min(1, posteriorUncertainty(posterior) * 4.5);
  const ageNeed = posterior.lastSeenAt ? Math.min(1, Math.max(0, now - posterior.lastSeenAt) / (30 * DAY)) : 1;
  return Math.min(1, 0.45 * coverageNeed + 0.35 * uncertaintyNeed + 0.20 * ageNeed);
}

export function retentionSummary(skill) {
  const e = ensureEvidenceState(skill?.evidence);
  return Object.fromEntries(Object.keys(RETENTION_BANDS).map((band) => [band, {
    attempts: e.retention[band].attempts,
    mastery: posteriorMastery(e.retention[band]),
    uncertainty: posteriorUncertainty(e.retention[band]),
    lastSeenAt: e.retention[band].lastSeenAt
  }]));
}

export function axisSummary(skill) {
  const e = ensureEvidenceState(skill?.evidence);
  return {
    production: { attempts: e.production.attempts, mastery: posteriorMastery(e.production), uncertainty: posteriorUncertainty(e.production) },
    transfer: { attempts: e.transfer.attempts, mastery: posteriorMastery(e.transfer), uncertainty: posteriorUncertainty(e.transfer) }
  };
}
